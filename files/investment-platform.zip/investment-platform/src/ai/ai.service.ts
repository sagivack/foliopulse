import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { MarketService } from '../market/market.service';
import { ClaudeService } from './claude.service';
import {
  RecommendationResponseDto,
  AiAnswerResponseDto,
} from './dto/recommendation-response.dto';

/**
 * Service métier du module AI (cahier des charges section 3.5) :
 *  - Analyse personnalisée
 *  - Réponses aux questions
 *  - Recommandations basées sur profil + données Finnhub
 */
@Injectable()
export class AiService {
  private readonly logger = new Logger(AiService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly market: MarketService,
    private readonly claude: ClaudeService,
  ) {}

  /**
   * Génère une recommandation IA pour un symbole donné, contextualisée
   * par le profil de risque de l'utilisateur (InvestmentProfile) et les
   * données de marché en temps réel (quote + sentiment Finnhub).
   */
  async generateRecommendation(
    userId: string,
    symbol: string,
  ): Promise<RecommendationResponseDto> {
    const profile = await this.prisma.investmentProfile.findFirst({
      where: { userId },
      orderBy: { id: 'desc' },
    });

    if (!profile) {
      throw new NotFoundException(
        "Aucun profil d'investissement trouvé — complète le questionnaire d'abord",
      );
    }

    // Récupère les données de marché en parallèle pour rester sous les 2s (objectif SMART)
    const [quote, sentiment] = await Promise.all([
      this.market.getQuote(symbol),
      this.market.getSentiment(symbol).catch(() => null), // le sentiment peut manquer pour certains titres
    ]);

    const systemPrompt = `Tu es un conseiller financier IA intégré à une plateforme d'investissement.
Tu génères des recommandations claires et pédagogiques, jamais des conseils financiers réglementés.
Tu dois toujours répondre en JSON strict, sans texte avant ou après, avec exactement ces champs :
{
  "stance": "ACHETER" | "CONSERVER" | "VENDRE" | "EVITER",
  "confidence": <nombre entre 0 et 100>,
  "summary": "<résumé en 2-3 phrases, langage simple>",
  "reasoning": "<analyse plus détaillée, 4-6 phrases>",
  "risks": ["<risque 1>", "<risque 2>", "<risque 3>"]
}
Adapte le ton et l'agressivité de la recommandation au profil de risque fourni.
Rappelle implicitement que ceci est éducatif, pas un conseil financier personnalisé réglementé.`;

    const userPrompt = `Profil investisseur :
- Type : ${profile.type}
- Tolérance au risque : ${profile.riskTolerance}
- Horizon : ${profile.horizon}
- Score de risque : ${profile.score}

Données de marché pour ${quote.symbol} :
- Prix actuel : ${quote.currentPrice}
- Variation : ${quote.change} (${quote.percentChange}%)
- Plus haut / plus bas du jour : ${quote.high} / ${quote.low}
- Clôture précédente : ${quote.previousClose}
${
  sentiment
    ? `- Sentiment marché : ${sentiment.bullishPercent}% haussier / ${sentiment.bearishPercent}% baissier (buzz: ${sentiment.buzzScore})`
    : '- Sentiment marché : non disponible pour ce titre'
}

Génère une recommandation adaptée à ce profil pour ce titre.`;

    const aiResult = await this.claude.completeJson<{
      stance: RecommendationResponseDto['stance'];
      confidence: number;
      summary: string;
      reasoning: string;
      risks: string[];
    }>(systemPrompt, userPrompt);

    return {
      symbol: quote.symbol,
      stance: aiResult.stance,
      confidence: aiResult.confidence,
      summary: aiResult.summary,
      reasoning: aiResult.reasoning,
      risks: aiResult.risks,
      generatedAt: new Date().toISOString(),
      profileType: profile.type,
    };
  }

  /**
   * Répond à une question libre de l'utilisateur, avec contexte de
   * marché optionnel si un symbole est fourni.
   */
  async askQuestion(
    userId: string,
    question: string,
    symbol?: string,
  ): Promise<AiAnswerResponseDto> {
    const profile = await this.prisma.investmentProfile.findFirst({
      where: { userId },
      orderBy: { id: 'desc' },
    });

    let marketContext = '';
    if (symbol) {
      try {
        const quote = await this.market.getQuote(symbol);
        marketContext = `\nContexte marché actuel pour ${quote.symbol} : prix ${quote.currentPrice}, variation ${quote.percentChange}%.`;
      } catch {
        this.logger.warn(`Impossible de récupérer le contexte pour ${symbol}`);
      }
    }

    const systemPrompt = `Tu es un assistant pédagogique intégré à une plateforme d'investissement.
Tu expliques des concepts financiers simplement, sans jargon inutile, adapté à un investisseur ${
      profile ? `de profil "${profile.type}"` : 'débutant'
    }.
Tu ne donnes jamais de conseil financier personnalisé réglementé — tu expliques et informes.
Réponds en 3 à 8 phrases maximum, en français, ton clair et rassurant.`;

    const userPrompt = `Question : ${question}${marketContext}`;

    const answer = await this.claude.completeText(systemPrompt, userPrompt);

    return {
      answer,
      relatedSymbol: symbol,
      generatedAt: new Date().toISOString(),
    };
  }
}
