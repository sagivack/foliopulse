import { Injectable, Logger, InternalServerErrorException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Anthropic from '@anthropic-ai/sdk';

/**
 * Client bas niveau autour du SDK Anthropic.
 * Objectif SMART du cahier des charges : générer une recommandation IA
 * en moins de 2 secondes -> on utilise un modèle rapide (Sonnet) et on
 * garde max_tokens raisonnable.
 */
@Injectable()
export class ClaudeService {
  private readonly logger = new Logger(ClaudeService.name);
  private readonly client: Anthropic;
  private readonly model: string;

  constructor(private readonly configService: ConfigService) {
    const apiKey = this.configService.get<string>('ANTHROPIC_API_KEY');

    if (!apiKey) {
      this.logger.warn('ANTHROPIC_API_KEY manquante — vérifie ton fichier .env');
    }

    this.client = new Anthropic({ apiKey });
    this.model = this.configService.get<string>('CLAUDE_MODEL') ?? 'claude-sonnet-4-6';
  }

  /**
   * Appelle Claude avec un system prompt + message utilisateur, et
   * force une sortie JSON stricte (parsée par l'appelant).
   */
  async completeJson<T>(systemPrompt: string, userPrompt: string): Promise<T> {
    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 1024,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }],
      });

      const textBlock = response.content.find((block) => block.type === 'text');

      if (!textBlock || textBlock.type !== 'text') {
        throw new Error('Réponse Claude sans contenu textuel');
      }

      const cleaned = textBlock.text
        .trim()
        .replace(/^```json\s*/i, '')
        .replace(/^```\s*/i, '')
        .replace(/```\s*$/i, '');

      return JSON.parse(cleaned) as T;
    } catch (err) {
      this.logger.error('Erreur lors de l\'appel à Claude (JSON)', err as Error);
      throw new InternalServerErrorException(
        'Le service IA est momentanément indisponible',
      );
    }
  }

  /** Variante texte libre, utilisée pour les réponses conversationnelles */
  async completeText(systemPrompt: string, userPrompt: string): Promise<string> {
    try {
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 800,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }],
      });

      const textBlock = response.content.find((block) => block.type === 'text');

      if (!textBlock || textBlock.type !== 'text') {
        throw new Error('Réponse Claude sans contenu textuel');
      }

      return textBlock.text.trim();
    } catch (err) {
      this.logger.error('Erreur lors de l\'appel à Claude (texte)', err as Error);
      throw new InternalServerErrorException(
        'Le service IA est momentanément indisponible',
      );
    }
  }
}
