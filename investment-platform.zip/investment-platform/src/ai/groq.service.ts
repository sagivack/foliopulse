import { Injectable, Logger, InternalServerErrorException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

/**
 * Client bas niveau autour de l'API Groq (https://console.groq.com).
 * Groq propose un tier gratuit avec des modèles open-source (Llama 3.1,
 * Mixtral...) servis à très haute vitesse — utile pour l'objectif SMART
 * du cahier des charges : générer une recommandation IA en < 2 secondes.
 *
 * L'API Groq est compatible avec le format de requête OpenAI
 * (endpoint /chat/completions), donc pas besoin de SDK dédié : un simple
 * fetch suffit.
 */
@Injectable()
export class GroqService {
  private readonly logger = new Logger(GroqService.name);
  private readonly apiKey: string;
  private readonly model: string;
  private readonly baseUrl = 'https://api.groq.com/openai/v1/chat/completions';

  constructor(private readonly configService: ConfigService) {
    this.apiKey = this.configService.get<string>('GROQ_API_KEY') ?? '';
    // llama-3.1-8b-instant : rapide et gratuit, bon pour un MVP
    this.model =
      this.configService.get<string>('GROQ_MODEL') ?? 'llama-3.1-8b-instant';

    if (!this.apiKey) {
      this.logger.warn('GROQ_API_KEY manquante — vérifie ton fichier .env');
    }
  }

  private async chat(
    systemPrompt: string,
    userPrompt: string,
    maxTokens: number,
    jsonMode: boolean,
  ): Promise<string> {
    let response: Response;

    try {
      response = await fetch(this.baseUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: this.model,
          max_tokens: maxTokens,
          temperature: 0.4,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt },
          ],
          ...(jsonMode ? { response_format: { type: 'json_object' } } : {}),
        }),
      });
    } catch (err) {
      this.logger.error('Erreur réseau vers Groq', err as Error);
      throw new InternalServerErrorException(
        'Le service IA est momentanément indisponible',
      );
    }

    if (!response.ok) {
      const errBody = await response.text().catch(() => '');
      this.logger.error(`Groq a répondu ${response.status} : ${errBody}`);
      throw new InternalServerErrorException(
        'Le service IA est momentanément indisponible',
      );
    }

    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content;

    if (!content) {
      throw new InternalServerErrorException('Réponse IA vide');
    }

    return content.trim();
  }

  /** Appelle Groq et force une sortie JSON stricte (parsée par l'appelant) */
  async completeJson<T>(systemPrompt: string, userPrompt: string): Promise<T> {
    const text = await this.chat(systemPrompt, userPrompt, 1024, true);

    const cleaned = text
      .replace(/^```json\s*/i, '')
      .replace(/^```\s*/i, '')
      .replace(/```\s*$/i, '');

    try {
      return JSON.parse(cleaned) as T;
    } catch (err) {
      this.logger.error('Impossible de parser la réponse JSON de Groq', err as Error);
      throw new InternalServerErrorException('Réponse IA invalide');
    }
  }

  /** Variante texte libre, utilisée pour les réponses conversationnelles */
  async completeText(systemPrompt: string, userPrompt: string): Promise<string> {
    return this.chat(systemPrompt, userPrompt, 800, false);
  }
}
